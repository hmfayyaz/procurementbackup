<?php
include_once '../config/database.php';

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50)  NOT NULL,
        password VARCHAR(255) NOT NULL
    )");
    echo "Table 'users' created successfully.\n";
} catch (PDOException $e) {
    echo "Error creating table: " . $e->getMessage() . "\n";
}
