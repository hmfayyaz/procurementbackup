<?php
$json_data = file_get_contents('php://input');
// Decode the JSON data
$decoded_data = json_decode($json_data, true);

var_dump($decoded_data);exit;