<?php

class PlansController {

    private $pdo;
    private $dbHelper;

    public function __construct($pdo, $dbHelper) {
        $this->pdo = $pdo;
        $this->dbHelper = $dbHelper;
    }
    public function store() {
        $title = $_POST['title'];
        $discount = $_POST['discount'];
        $amount = $_POST['amount'];
        
        $Data = [
            'title' => $title,
            'discount' => $discount,
            'amount' => $amount
        ];

        $helper = new DatabaseHelper($this->pdo, 'plans');
        $insertedPlanId = $helper->createRecord($Data);
        
        if ($insertedPlanId !== null) {
            $responseData = array(
                'status' => 'success',
                'message' => 'Plan created successfully',
                'planid' => $insertedPlanId
            );
                http_response_code(200);
                echo json_encode($responseData);
        } else {
            $responseData = array(
                'status' => 'failed',
                'message' => 'Failed to create plan'
            );
                http_response_code(500);
                echo json_encode($responseData);
        }
    }
    public function update() {

        $planid = $_POST['plan_id'];
        $title = $_POST['title'];
        $discount = $_POST['discount'];
        $amount = $_POST['amount'];
        
        $plan_exist = $this->getPlanData($planid);
        if(!$plan_exist){
            $responseData = array(
                'status' => 'failed',
                'message' => 'Plan not found'
            );
                http_response_code(500);
                echo json_encode($responseData);
        }
        else{
                $Data = [
                    'title' => $title,
                    'discount' => $discount,
                    'amount' => $amount
                ];

                $helper = new DatabaseHelper($this->pdo, 'plans');
                $insertedPlanId = $helper->updateRecord($planid, $Data);
                
                if ($insertedPlanId !== null) {
                    $responseData = array(
                        'status' => 'success',
                        'message' => 'Plan update successfully'
                    );
                        http_response_code(200);
                        echo json_encode($responseData);
                } else {
                    $responseData = array(
                        'status' => 'failed',
                        'message' => 'Failed to update plan'
                    );
                        http_response_code(500);
                        echo json_encode($responseData);
                }
            }
        
    }
    public function fetch() {
        
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM `plans` where status = 1");
            $stmt->execute();
            $plan = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if(!$plan){
                $responseData = array(
                    'status' => 'failed',
                    'message' => 'Plans not found'
                );
                    http_response_code(500);
                    echo json_encode($responseData);
            }
            else{
            $responseData = array(
                'status' => 'success',
                'message' => 'Plans',
                'data' => $plan
            );
                http_response_code(200);
                echo json_encode($responseData);
            }
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }

    public function getPlanData($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM `plans` WHERE id = ?");
            $stmt->execute([$id]);
            $plan = $stmt->fetch(PDO::FETCH_ASSOC);
            return $plan ? $plan : null;
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }
    

}