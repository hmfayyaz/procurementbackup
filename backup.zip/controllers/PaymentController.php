<?php

class PaymentController {

    private $pdo;
    private $dbHelper;

    public function __construct($pdo, $dbHelper) {
        $this->pdo = $pdo;
        $this->dbHelper = $dbHelper;
    }
  
    public function update() {

        $pay_id = $_POST['pay_id'];
        $title = $_POST['title'];
        $api_key = $_POST['api_key'];
        $api_secret = $_POST['api_secret'];
        
        $payn_exist = $this->getPayData($pay_id);
        if(!$payn_exist){
            $responseData = array(
                'status' => 'failed',
                'message' => 'Payment not found'
            );
                http_response_code(500);
                echo json_encode($responseData);
        }
        else{
                $Data = [
                    'title' => $title,
                    'api_key' => $api_key,
                    'api_secret' => $api_secret
                ];

                $helper = new DatabaseHelper($this->pdo, 'payment_setting');
                $insertedPayId = $helper->updateRecord($pay_id, $Data);
                
                if ($insertedPayId !== null) {
                    $responseData = array(
                        'status' => 'success',
                        'message' => 'Setting update successfully'
                    );
                        http_response_code(200);
                        echo json_encode($responseData);
                } else {
                    $responseData = array(
                        'status' => 'failed',
                        'message' => 'Failed to update Setting'
                    );
                        http_response_code(500);
                        echo json_encode($responseData);
                }
            }
        
    }
    public function fetch() {
        
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM `payment_setting`");
            $stmt->execute();
            $pay_setting = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if(!$pay_setting){
                $responseData = array(
                    'status' => 'failed',
                    'message' => 'Payment not found'
                );
                    http_response_code(500);
                    echo json_encode($responseData);
            }
            else{
            $responseData = array(
                'status' => 'success',
                'message' => 'Payment Setting',
                'data' => $pay_setting
            );
                http_response_code(200);
                echo json_encode($responseData);
            }
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }

    public function getPayData($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM `payment_setting` WHERE id = ?");
            $stmt->execute([$id]);
            $plan = $stmt->fetch(PDO::FETCH_ASSOC);
            return $plan ? $plan : null;
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }
    

}