<?php

class CronController
{
	private $pdo;
	private $trackingHelper;

	public function __construct( $pdo, $dbHelper, $authorize, $connectwise, $trackingHelper )
	{
		$this->pdo            = $pdo;
		$this->trackingHelper = $trackingHelper;
	}

	public function tracking_numbers()
	{
		$stmt = $this->pdo->prepare( "SELECT * FROM users" );
		$stmt->execute( [] );
		$users            = $stmt->fetchAll( PDO::FETCH_ASSOC );
		$tracking_numbers = [];

		foreach ( $users as $user ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM portal_setting WHERE user_id = ?" );
			$stmt->execute( [ $user['id'] ] );
			$settings    = $stmt->fetch( PDO::FETCH_ASSOC );
			$endpoint    = $settings['cw_end_point'] ?? false;
			$client_id   = $settings['cw_client_id'] ?? false;
			$public      = $settings['cw_public_key'] ?? false;
			$private     = $settings['cw_private_key'] ?? false;
			$company_id  = $settings['cw_company_id'] ?? false;
			$page        = 1;
			$limit       = 1000;
			$connectwise = new ConnectWise( $endpoint, $client_id, $public, $private, $company_id );

			if ( $connectwise ) {
				$companies = $connectwise->getCompanies( $page, $limit );
				foreach ( $companies as $company ) {
					$po = $connectwise->getPurchaseOrders( $company['id'], $page, $limit );
					foreach ( $po as $po_item ) {
						$nos                                = explode( ' ', $po_item['tracking_number'] );
						$tracking_numbers[ $po_item['id'] ] = $nos;
					}
					//$tracking_numbers = array_merge( $tracking_numbers, array_column( $po, 'tracking_number' ) );
				}
			}
		}
		$this->trackingHelper->analyze_tracking_numbers( $tracking_numbers );
	}

	public function track()
	{
		$stmt = $this->pdo->prepare( "SELECT * FROM trackings WHERE source_id IS NULL OR status = ?" );
		$stmt->execute( [ 'queue' ] );
		$records  = $stmt->fetchAll( PDO::FETCH_ASSOC );
		$response = [];

		foreach ( $records as $record ) {
			$tracking_number = $record['tracking_number'];
			$res             = $this->trackingHelper->create_vendor_tracking( $tracking_number );
			$tracking        = $res['data']['tracking'] ?? false;

			$this->trackingHelper->update_local_tracking( $tracking );
			$response[] = $res;
		}

		echo json_encode( $response );
	}
}
