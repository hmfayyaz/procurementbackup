<?php

class SuperAdminController
{

	private $pdo;
	private $dbHelper;
	private $authorize;

	public function __construct( $pdo, $dbHelper, $authorize )
	{
		$this->pdo       = $pdo;
		$this->dbHelper  = $dbHelper;
		$this->authorize = $authorize;
	}

	public function store()
	{
		$username   = $_POST['username'];
		$email      = $_POST['email'];
		$portal_url = $_POST['portal_url'];
		$password   = md5( $_POST['password'] );

		// Check if username exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE username = :username" );
		$stmt->bindParam( ':username', $username, PDO::PARAM_STR );
		$stmt->execute();
		$userByUsername = $stmt->fetch( PDO::FETCH_ASSOC );

		// Check if email exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE email = :email" );
		$stmt->bindParam( ':email', $email, PDO::PARAM_STR );
		$stmt->execute();
		$userByEmail = $stmt->fetch( PDO::FETCH_ASSOC );

		// Check if portal url exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE portal_url = :portal_url" );
		$stmt->bindParam( ':portal_url', $portal_url, PDO::PARAM_STR );
		$stmt->execute();
		$userByPortal = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( $userByUsername || $userByEmail || $userByPortal ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'Username/Email/Portal already exists'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {

			$userData = [
				'username'   => $username,
				'email'      => $email,
				'portal_url' => $portal_url,
				'password'   => $password
			];

			$helper         = new DatabaseHelper( $this->pdo, 'users' );
			$insertedUserId = $helper->createRecord( $userData );

            if ( $insertedUserId ) {
                $helper = new DatabaseHelper( $this->pdo, 'portal_setting' );
                $helper->createRecord( [ 'user_id' => $insertedUserId, 'portal_url' => $portal_url] );
            }
			if ( $insertedUserId !== null ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'User created successfully',
					'userid'  => $insertedUserId
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Failed to create user'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		}
	}

	public function update()
	{

		$userid   = $_POST['user_id'];
		$username = $_POST['username'];
		$email    = $_POST['email'];

		$user_exist = $this->getUserData( $userid );
		if ( ! $user_exist ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'User not found'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {
			$userData = [
				'username'     => $username,
				'email'        => $email,
				'display_name' => $_POST['display_name'],
				'phone_number' => $_POST['phone_number']
			];

			$helper         = new DatabaseHelper( $this->pdo, 'users' );
			$insertedUserId = $helper->updateRecord( $userid, $userData );

			if ( $insertedUserId !== null ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'User update successfully',
					'userid'  => $userid
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Failed to update user'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		}

	}

	public function delete()
	{

		$userid = $_POST['user_id'];

		$user_exist = $this->getUserData( $userid );
		if ( ! $user_exist ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'User not found'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {
			$helper = new DatabaseHelper( $this->pdo, 'users' );
			$result = $helper->deleteRecord( $userid );

			if ( $result ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'User deleted successfully'
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Failed to delete user'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		}
	}

	public function getUserData( $id )
	{
		try {
			$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE id = ?" );
			$stmt->execute( [ $id ] );
			$user = $stmt->fetch( PDO::FETCH_ASSOC );

			return $user ? $user : null;
		} catch ( PDOException $e ) {
			// Handle the exception
			return null;
		}
	}


}
