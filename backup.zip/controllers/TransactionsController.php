<?php

class TransactionsController {

    private $pdo;
    private $dbHelper;

    public function __construct($pdo, $dbHelper) {
        $this->pdo = $pdo;
        $this->dbHelper = $dbHelper;
    }

    public function fetch() {
        
        try {
            $stmt = $this->pdo->prepare("SELECT transactions.*, users.username 
            FROM transactions 
            JOIN users ON transactions.user_id = users.id 
            WHERE transactions.status = 1");
            $stmt->execute();
            $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if(!$transactions){
                $responseData = array(
                    'status' => 'failed',
                    'message' => 'Transaction not found'
                );
                    http_response_code(500);
                    echo json_encode($responseData);
            }
            else{
            $responseData = array(
                'status' => 'success',
                'message' => 'Transactions',
                'data' => $transactions
            );
                http_response_code(200);
                echo json_encode($responseData);
            }
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }

}