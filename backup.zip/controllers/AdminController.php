<?php

class AdminController
{

	private $pdo;
	private $dbHelper;
	private $authorize;

	public function __construct( $pdo, $dbHelper, $authorize )
	{
		$this->pdo       = $pdo;
		$this->dbHelper  = $dbHelper;
		$this->authorize = $authorize;
	}

	public function store()
	{
		$username   = $_POST['username'];
		$email      = $_POST['email'];
		$portal_url = $_POST['portal_url'];
		$password   = md5( $_POST['password'] );

		// Check if username exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE username = :username" );
		$stmt->bindParam( ':username', $username, PDO::PARAM_STR );
		$stmt->execute();
		$userByUsername = $stmt->fetch( PDO::FETCH_ASSOC );

		// Check if email exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE email = :email" );
		$stmt->bindParam( ':email', $email, PDO::PARAM_STR );
		$stmt->execute();
		$userByEmail = $stmt->fetch( PDO::FETCH_ASSOC );

		// Check if portal_url exists
		$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE portal_url = :portal_url" );
		$stmt->bindParam( ':portal_url', $portal_url, PDO::PARAM_STR );
		$stmt->execute();
		$userByPortal = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( $userByUsername || $userByEmail || $userByPortal ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'Username/Email/Portal already exists'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {
			$userData = [
				'username'   => $username,
				'email'      => $email,
				'portal_url' => $portal_url,
				'password'   => $password,
				'parent_id'  => $this->authorize['id'] ?? null,
				'is_admin'   => '0'
			];

			$helper         = new DatabaseHelper( $this->pdo, 'users' );
			$insertedUserId = $helper->createRecord( $userData );

			if ( $insertedUserId !== null ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'User created successfully',
					'userid'  => $insertedUserId
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Failed to create user'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		}

	}

	public function update()
    {

        $userid = $this->authorize['id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $label = $_POST['label'];
        $portal_url = $_POST['portal_url'];

        if (isset($_POST['user_id'])) {
            $userid = $_POST['user_id'];
        }
        // Check if username exists
        $stmt = $this->pdo->prepare("SELECT * FROM `users` WHERE username = :username AND id != :user_id");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $userByUsername = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if email exists
        $stmt = $this->pdo->prepare("SELECT * FROM `users` WHERE email = :email AND id != :user_id");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $userByEmail = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if portal_url exists
        $stmt = $this->pdo->prepare("SELECT * FROM `users` WHERE portal_url = :portal_url AND id != :user_id");
        $stmt->bindParam(':portal_url', $portal_url, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $userid, PDO::PARAM_INT);
        $stmt->execute();
        $userByUrl = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($userByUsername || $userByEmail || $userByUrl) {
            $responseData = array(
                'status' => 'failed',
                'message' => 'Username/Email already exists'
            );
            http_response_code(500);
            echo json_encode($responseData);
        }
        else{
        $user_exist = $this->getUserData($userid);
        if (!$user_exist) {
            $responseData = array(
                'status' => 'failed',
                'message' => 'User not found'
            );
            http_response_code(500);
            echo json_encode($responseData);
        } else if ($user_exist['is_admin'] == 1 || $user_exist['is_admin'] == 2) {
            $userData = [
                'username' => $username,
                'email' => $email,
                'display_name' => $_POST['display_name'],
                'phone_number' => $_POST['phone_number'],
                'portal_url' => $portal_url,
                'parent_id' => $this->authorize['id']
            ];

            $helper = new DatabaseHelper($this->pdo, 'users');
            $insertedUserId = $helper->updateRecord($userid, $userData);

            if ($insertedUserId !== null) {
                if (!empty($label) && !empty($portal_url)) {
                    $stmt = $this->pdo->prepare("SELECT id FROM portal_setting WHERE user_id = ?");
                    $stmt->execute([$userid]);
                    $portal = $stmt->fetch(PDO::FETCH_ASSOC);

                    $helper = new DatabaseHelper($this->pdo, 'portal_setting');
                    $helper->updateRecord($portal['id'], ['label' => $label, 'portal_url' => $portal_url]);
                }

                $stmt = $this->pdo->prepare("SELECT u.*, p.label FROM `users` as u left join portal_setting p on u.id = p.user_id WHERE u.id = ?");
                $stmt->execute([$userid]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                $responseData = array(
                    'status' => 'success',
                    'message' => 'User update successfully',
                    'data' => $user
                );
                http_response_code(200);
                echo json_encode($responseData);
            } else {
                $responseData = array(
                    'status' => 'failed',
                    'message' => 'Failed to update user'
                );
                http_response_code(500);
                echo json_encode($responseData);
            }
        }
    }
	}

	public function delete()
	{

		$userid = $_POST['user_id'];

		$user_exist = $this->getUserData( $userid );
		if ( ! $user_exist ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'User not found'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {
			$helper = new DatabaseHelper( $this->pdo, 'users' );
			$result = $helper->deleteRecord( $userid );

			if ( $result ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'User deleted successfully'
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Failed to delete user'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		}
	}

	public function getUsers()
	{
		try {
			$stmt = $this->pdo->prepare( "SELECT u.*, p.label, p.portal_url FROM `users` as u left join portal_setting p on u.id = p.user_id WHERE u.is_admin = ?" );
			$stmt->execute( [ 2 ] );
			$user = $stmt->fetchAll( PDO::FETCH_ASSOC );
			if ( $user ) {
				$responseData = array(
					'status'  => 'success',
					'message' => 'Users List',
					'data'    => $user
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			} else {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Not Found'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			}
		} catch ( PDOException $e ) {
			// Handle the exception
			return null;
		}
	}

	public function getUserData( $id )
	{
		try {
			$stmt = $this->pdo->prepare( "SELECT * FROM `users` WHERE id = ?" );
			$stmt->execute( [ $id ] );
			$user = $stmt->fetch( PDO::FETCH_ASSOC );

			return $user ? $user : null;
		} catch ( PDOException $e ) {
			// Handle the exception
			return null;
		}
	}
}
