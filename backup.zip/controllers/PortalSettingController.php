<?php

class PortalSettingController
{

	private $pdo;
	private $dbHelper;
	private $authorize;

	public function __construct( $pdo, $dbHelper, $authorize )
	{
		$this->pdo       = $pdo;
		$this->dbHelper  = $dbHelper;
		$this->authorize = $authorize;
	}

	public function update()
	{
		$post_keys    = [
			'label'           => 'label',
			'portal_url'      => 'portal_url',
			'logo'            => 'logo_media',
			'color_scheme'    => 'color_scheme',
			'cw_company_type' => 'cw_company_type',
			'cw_contact_type' => 'cw_contact_type',
			'cw_end_point'    => 'cw_end_point',
			'cw_client_id'    => 'cw_client_id',
			'cw_public_key'   => 'cw_public_key',
			'cw_private_key'  => 'cw_private_key',
			'cw_company_id'   => 'cw_company_id',
			'master_password' => 'master_password',
		];
		$data         = [];
		$responseData = [ 'status' => true ];

		foreach ( $post_keys as $key => $value ) {
			if ( isset( $_POST[ $key ] ) ) {
				$data[ $value ] = $_POST[ $key ];
			}
		}

		$data['user_id'] = $this->authorize['id'];
		$company_id      = $data['cw_company_id'] ?? false;
		if ( ! empty( $data['cw_company_id'] ) ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM `users` where company_id = ? and id != ?" );
			$stmt->execute( [ $data['cw_company_id'], $this->authorize['id'] ] );
			$user = $stmt->fetchAll( PDO::FETCH_ASSOC );

			if ( $user ) {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Company Already Exists'
				);
			}
		}

		if ( ! empty( $data['portal_url'] ) ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM `users` where portal_url = ? and id != ?" );
			$stmt->execute( [ $data['portal_url'], $this->authorize['id'] ] );
			$user = $stmt->fetchAll( PDO::FETCH_ASSOC );

			if ( $user ) {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Portal Already Exists'
				);
			}
		}

		if ( $responseData['status'] === 'failed' ) {
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {

			$stmt = $this->pdo->prepare( "SELECT * FROM `portal_setting` where user_id = ?" );
			$stmt->execute( [ $this->authorize['id'] ] );
			$portal_setting = $stmt->fetch( PDO::FETCH_ASSOC );

			if ( $portal_setting ) {
				$helper = new DatabaseHelper( $this->pdo, 'portal_setting' );
				$helper->updateRecord( $portal_setting['id'], $data );
			} else {
				$helper = new DatabaseHelper( $this->pdo, 'portal_setting' );
				$helper->createRecord( $data );
			}

			if ( $company_id ) {
                $helper = new DatabaseHelper( $this->pdo, 'users' );
				$helper->updateRecord( $this->authorize['id'], [ 'company_id' => $company_id, 'portal_url' => $data['portal_url']] );
			}

			$responseData = array(
				'status'  => 'success',
				'message' => 'Setting update successfully',
			);
			http_response_code( 200 );
			echo json_encode( $responseData );
		}
	}

	public function fetch()
	{
		try {
			$stmt = $this->pdo->prepare( "SELECT * FROM `portal_setting` where user_id = ?" );
			$stmt->execute( [ $this->authorize['id'] ] );
			$pay_setting = $stmt->fetch( PDO::FETCH_ASSOC );

			if ( ! $pay_setting ) {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Setting not found'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
			} else {
				$pay_setting['logo_media_url'] = false;

				if ( ! empty( $pay_setting['logo_media'] ) ) {
					$stmt = $this->pdo->prepare( "SELECT * FROM `media_files` where id = ?" );
					$stmt->execute( [ $pay_setting['logo_media'] ] );
					$media = $stmt->fetch( PDO::FETCH_ASSOC );

					$pay_setting['logo_media_url'] = $media['url'] ?? false;
				}

				$responseData = array(
					'status'  => 'success',
					'message' => 'Portal Setting',
					'data'    => $pay_setting
				);
				http_response_code( 200 );
				echo json_encode( $responseData );
			}
		} catch ( PDOException $e ) {
			return null;
		}
	}

	public function getSettingData( $id )
	{
		try {
			$stmt = $this->pdo->prepare( "SELECT * FROM `portal_setting` WHERE id = ?" );
			$stmt->execute( [ $id ] );
			$plan = $stmt->fetch( PDO::FETCH_ASSOC );

			return $plan ? $plan : null;
		} catch ( PDOException $e ) {
			return null;
		}
	}

	public function get_media()
	{
		$id                     = $_GET['id'] ?? false;
		$responseData['status'] = 'error';

		try {
			if ( $id ) {
				$stmt = $this->pdo->prepare( "SELECT * FROM `media_files` WHERE id = ?" );
				$stmt->execute( [ $id ] );
				$media = $stmt->fetch( PDO::FETCH_ASSOC );

				if ( $media ) {
					$responseData['status'] = 'success';
					$responseData['data']   = $media;

					http_response_code( 200 );
					echo json_encode( $media );
					die;
				}
			}
		} catch ( PDOException $e ) {
			// nothing
		}
		http_response_code( 500 );
		echo json_encode( $responseData );
	}

	public function upload_media()
	{
		$responseData           = [];
		$responseData['status'] = false;
		$allowed_types          = [ 'png', 'jpg', 'gif', 'svg' ];

		if ( $_FILES['file'] ) {
			$target_dir      = dirname( __FILE__ ) . '/../uploads/';
			$filename        = basename( $_FILES["file"]["name"] );
			$file_path       = "uploads/{$filename}";
			$target_file     = $target_dir . $filename;
			$target_file_url = BASEURL . $file_path;
			$file_type       = strtolower( pathinfo( $target_file, PATHINFO_EXTENSION ) );

			if ( in_array( $file_type, $allowed_types ) ) {
				$responseData['status'] = move_uploaded_file( $_FILES["file"]["tmp_name"], $target_file );

				if ( $responseData['status'] ) {
					$media   = [
						'path'      => $file_path,
						'full_path' => $target_file,
						'url'       => $target_file_url
					];
					$helper  = new DatabaseHelper( $this->pdo, 'media_files' );
					$last_id = $helper->createRecord( $media );

					if ( $last_id ) {
						$media['id']          = $last_id;
						$responseData['data'] = $media;
					}
				}
			} else {
				$responseData['error'] = 'File type not supported';
			}

			http_response_code( 200 );
			echo json_encode( $responseData );
		}
	}
}
