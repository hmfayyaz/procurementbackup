<?php

class ClientController
{
	private $pdo;
	private $dbHelper;
	private $authorize;
	private $connectwise;
	private $trackingHelper;

	public function __construct( $pdo, $dbHelper, $clientAuthorize, $connectwise, $trackingHelper )
	{
		$this->pdo            = $pdo;
		$this->dbHelper       = $dbHelper;
		$this->authorize      = $clientAuthorize;
		$this->connectwise    = $connectwise;
		$this->trackingHelper = $trackingHelper;
	}

	public function getorderbypo()
	{
		$po_id  = $_POST['po'];
		$page   = $_GET['page'] ?? 1;
		$orders = $this->connectwise->getLineItems( $po_id, $page );
		$paging = $this->connectwise->getPagination( $page );
		$po     = $this->connectwise->getPurchaseOrder( $po_id );

		$stmt = $this->pdo->prepare( "SELECT * FROM purchase_orders WHERE po_id = ?" );
		$stmt->execute( [ $po_id ] );
		$po_status          = $stmt->fetch( PDO::FETCH_ASSOC );
		$po['systemStatus'] = null;

		if ( $po_status ) {
			$po['systemStatus'] = $po_status['status'];
		}

		$responseData = array(
			'status'  => 'success',
			'message' => 'PO Orders',
			'data'    => $orders,
			"paging"  => $paging,
			"po"      => $po,
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function getpo()
	{
		$page       = $_GET['page'] ?? 1;
		$limit      = $_GET['limit'] ?? 100;
		$company_id = $this->authorize['company_id'];
		$po         = $this->connectwise->getPurchaseOrders( $company_id, $page, $limit );
		$paging     = $this->connectwise->getPagination( $page );
		$po_ids     = array_column( $po, 'id' );

		$po_ids = '(' . implode( ',', $po_ids ) . ')';
		$stmt   = $this->pdo->prepare( "SELECT * FROM purchase_orders WHERE po_id in {$po_ids}" );
		$stmt->execute();
		$po_statuses = $stmt->fetchAll( PDO::FETCH_ASSOC );

		$po = array_map( function ( $p ) use ( &$po_statuses ) {
			$p['systemStatus'] = null;

			if ( $po_statuses ) {
				foreach ( $po_statuses as $po_status ) {
					if ( $po_status['po_id'] == $p['id'] ) {
						$p['systemStatus'] = $po_status['status'];
					}
				}
			}

			return $p;
		}, $po );

		$responseData = array(
			"status"  => "success",
			"message" => "User Po's",
			"data"    => $po,
			"paging"  => $paging,
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function receive_quantity()
	{
		$purchase_order_id = $_REQUEST['po_id'];
		$product_id        = $_REQUEST['product_id'];
		$qty               = $_REQUEST['qty'];
		$line_items        = $updated_line_items = [];
		$unfilled_qty      = $qty;
		$line_items        = $this->connectwise->getLineItems( $purchase_order_id, 1, 1000, false );

		foreach ( $line_items as $line_item ) {
			if ( $line_item['product']['id'] == $product_id ) {
				if ( $unfilled_qty > 0 ) {
					$remaining = floatval( $line_item['quantity'] ) - floatval( $line_item['receivedQuantity'] );

					while ( $remaining > 0 && $unfilled_qty > 0 ) {
						$line_item['receivedStatus']   = 'PartiallyReceiveCloneRest';
						$line_item['receivedQuantity'] = floatval( $line_item['receivedQuantity'] ) + 1;
						$unfilled_qty --;

						$remaining = floatval( $line_item['quantity'] ) - floatval( $line_item['receivedQuantity'] );

						if ( $remaining <= 0 ) {
							$line_item['receivedStatus'] = 'FullyReceived';
						}

						$updated_line_items[ $line_item['id'] ] = $line_item;
					}
				}
			}

			$line_items[] = $line_item;
		}

		$updated_line_items = array_values( $updated_line_items );
		$updated            = $this->connectwise->updateLineItems( $purchase_order_id, $updated_line_items );
		$line_items         = $this->connectwise->getLineItems( $purchase_order_id, 1, 1000 );
		$fulfilled          = true;

		foreach ( $line_items as $line_item ) {
			$fulfilled &= $line_item['quantity'] == $line_item['receivedQuantity'];
		}

		$stmt = $this->pdo->prepare( "SELECT * FROM purchase_orders WHERE po_id = ?" );
		$stmt->execute( [ $purchase_order_id ] );
		$notified = $stmt->fetch( PDO::FETCH_ASSOC );

		$notified = isset( $notified['status'] ) && $notified['status'] == 'notified';

		http_response_code( 200 );
		echo json_encode( [
			                  'message'   => 'Quantity received successfully',
			                  'fulfilled' => $fulfilled,
			                  'notified'  => $notified,
		                  ] );
	}

	public function receive_quantity1()
	{
		$purchase_order_id  = $_REQUEST['po_id'];
		$line_item_id       = $_REQUEST['line_item_id'];
		$qty                = $_REQUEST['qty'];
		$updated_line_items = [];
		$unfilled_qty       = $qty;
		$line_item          = $this->connectwise->getLineItem( $purchase_order_id, $line_item_id );

		if ( $unfilled_qty > 0 ) {
			$remaining = floatval( $line_item['quantity'] ) - floatval( $line_item['receivedQuantity'] );

			while ( $remaining > 0 && $unfilled_qty > 0 ) {
				$line_item['receivedStatus']   = 'PartiallyReceiveCloneRest';
				$line_item['receivedQuantity'] = floatval( $line_item['receivedQuantity'] ) + 1;
				$unfilled_qty --;

				$remaining = floatval( $line_item['quantity'] ) - floatval( $line_item['receivedQuantity'] );

				if ( $remaining <= 0 ) {
					$line_item['receivedStatus'] = 'FullyReceived';
				}

				$updated_line_items[ $line_item['id'] ] = $line_item;
			}
		}

		$line_items[]       = $line_item;
		$updated_line_items = array_values( $updated_line_items );
		$updated            = $this->connectwise->updateLineItems( $purchase_order_id, $updated_line_items );
		$line_items         = $this->connectwise->getLineItems( $purchase_order_id, 1, 1000 );
		$fulfilled          = true;

		foreach ( $line_items as $line_item ) {
			$fulfilled &= $line_item['quantity'] == $line_item['receivedQuantity'];
		}

		$stmt = $this->pdo->prepare( "SELECT * FROM purchase_orders WHERE po_id = ?" );
		$stmt->execute( [ $purchase_order_id ] );
		$notified = $stmt->fetch( PDO::FETCH_ASSOC );

		$notified = isset( $notified['status'] ) && $notified['status'] == 'notified';

		http_response_code( 200 );
		echo json_encode( [
			                  'message'   => 'Quantity received successfully',
			                  'fulfilled' => $fulfilled,
			                  'notified'  => $notified,
		                  ] );
	}

	public function receive_signature()
	{
		$purchase_order_id = $_REQUEST['po_id'];
		$name              = $_REQUEST['name'];
		$purchase_order    = $this->connectwise->getPurchaseOrder( $purchase_order_id );
		$line_items        = $this->connectwise->getLineItems( $purchase_order_id, 1, 1000 );
		$client_name       = $purchase_order['customerCompany']['name'];
		$fulfilled         = true;
		$products          = [];
		$email_to          = "robert@hztech.biz";//get_fields( 'notification_email' );
		$notification_msg  = "";//get_fields( 'notification_msg' );

		if ( empty( $notification_msg ) ) {
			$notification_msg = 'This Purchase Order has been marked as "Received" by client. Please process in accordance with <a href="https://wiki.dhsforyou.com/display/DD/Receiving">DHS Receiving procedure</a>.';
		}

		foreach ( $line_items as $line_item ) {
			$fulfilled &= $line_item['quantity'] == $line_item['receivedQuantity'];

			if ( ! isset( $products[ $line_item['product']['identifier'] ] ) ) {
				$products[ $line_item['product']['identifier'] ] = $line_item;
			} else {
				$products[ $line_item['product']['identifier'] ]['quantity']         += $line_item['quantity'];
				$products[ $line_item['product']['identifier'] ]['receivedQuantity'] += $line_item['receivedQuantity'];
			}
		}


		if ( $fulfilled && ! empty( $email_to ) ) {

			$poNumber = $purchase_order['poNumber'];
			$subject  = "PO# {$poNumber} / {$client_name} / Received in Full";
			$msg      = '<div><p>' . $notification_msg . '</p></div>';
			$msg      .= "<div><strong>Client Name: </strong>{$client_name}</div>";
			$msg      .= "<div><strong>Purchase Order: </strong>{$poNumber}</div>";
			$msg      .= "<div><strong>E-Signature: </strong>{$name}</div>";
			$msg      .= "<div><h3>Line Items:</h3></div>";

			$products = array_values( $products );

			foreach ( $products as $product ) {
				$msg .= '<div style="margin-bottom: 20px;">';
				$msg .= '<div><strong>Product ID:</strong> ' . $product['product']['identifier'] . '</div>';
				$msg .= '<div><strong>Purchase Quantity:</strong> ' . $product['quantity'] . '</div>';
				$msg .= '<div><strong>Received Quantity:</strong> ' . $product['receivedQuantity'] . '</div>';
				$msg .= '</div>';
			}

			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: Procurement - Digicom <procurement@dhsforyou.com>' . "\r\n";
			$headers .= 'Reply-To: <procurement@dhsforyou.com>' . "\r\n";

			mail( $email_to, $subject, $msg, $headers );

			$po_data = [
				'status' => 'notified',
				'po_id'  => $purchase_order_id
			];

			$helper = new DatabaseHelper( $this->pdo, 'purchase_orders' );
			$helper->createRecord( $po_data );

			$responce = [
				'message' => 'E-signature received successfully',
				'status'  => 'notified',
				'po_id'   => $purchase_order_id
			];

			http_response_code( 200 );
			echo json_encode( $responce );
		}
	}

	public function dump()
	{
		$po_id        = 3123;
		$line_item_id = 5271;
		$line_items   = $this->connectwise->getLineItems( $po_id, 1, 1000 );
		$line_item    = $this->connectwise->getLineItem( $po_id, $line_item_id );

		$line_item['lineNumber']     = count( $line_items ) + 1;
		$line_item['quantity']       = 10;
		$line_item['receivedStatus'] = "PartiallyReceiveCloneRest";
		//$line_item = [ 'product' => [ 'id' => 1219 ], 'quantity' => 10 ];

		$r = $this->connectwise->addLineItem( $po_id, $line_item );
		echo json_encode( [ $line_item, $r ] );
	}

	public function add_tracking_number()
	{
		$po_id           = $_POST['po_id'];
		$tracking_number = $_POST['tracking_number'];
		$po              = $this->connectwise->getPurchaseOrder( $po_id );

		if ( empty( $po ) ) {
			$responseData = [
				'status'  => 'error',
				'message' => 'Purchase Order not found',
				'data'    => null
			];
			http_response_code( 500 );
		} else if ( empty( $po['trackingNumber'] ) ) {

			$po['trackingNumber'] = $tracking_number;
			$updated              = $this->connectwise->updatePurchaseOrder( $po_id, $po );

			$responseData = [
				'status'  => 'success',
				'message' => 'Tracking number added successfully',
				'data'    => $po
			];

			$this->trackingHelper->analyze_tracking_numbers( [ $po_id => [ $tracking_number ] ] );
			$res      = $this->trackingHelper->create_vendor_tracking( $tracking_number );
			$tracking = $res['data']['tracking'] ?? false;

			$this->trackingHelper->update_local_tracking( $tracking );

			http_response_code( 200 );
		} else {
			$responseData = [
				'status'  => 'error',
				'message' => 'Tracking number already placed',
				'data'    => null
			];
			http_response_code( 500 );
		}

		echo json_encode( $responseData );
	}

	public function tracking_info()
	{
		$po_id           = $_GET['po_id'];
		$tracking_number = $_GET['tracking_number'];
		$stmt            = $this->pdo->prepare( "SELECT * FROM trackings WHERE tracking_number = ?" );
		$stmt->execute( [ $tracking_number ] );
		$tracking = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( $tracking && ! empty( $tracking['checkpoints'] ) ) {
			$tracking['checkpoints'] = json_decode( $tracking['checkpoints'], true );

			$responseData = [
				'status' => 'success',
				'data'   => $tracking,
			];
			http_response_code( 200 );
		} else {
			$responseData = [
				'status'  => 'error',
				'message' => 'Tracking info not found',
				'data'    => null
			];
			http_response_code( 500 );
		}

		echo json_encode( $responseData );
	}
}
