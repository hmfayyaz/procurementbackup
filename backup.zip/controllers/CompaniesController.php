<?php

class CompaniesController
{
	private $pdo;
	private $dbHelper;
	private $authorize;
	private $connectwise;

	public function __construct( $pdo, $dbHelper, $authorize, $connectwise )
	{

		$this->pdo         = $pdo;
		$this->dbHelper    = $dbHelper;
		$this->authorize   = $authorize;
		$this->connectwise = $connectwise;
	}

	public function getcompanies()
	{
		$page         = $_GET['page'] ?? 1;
		$cw           = $this->connectwise;
		$companies    = $cw->getCompanies( $page );
		$paging       = $this->connectwise->getPagination( $page );
		$companies    = array_map( function ( $client ) use ( &$cw ) {
			$main_company_id = $cw->getCompanyId();
			$stmt            = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE company_id = ?" );
			$stmt->execute( [ $client['id'] ] );
			$session = $stmt->fetch( PDO::FETCH_ASSOC );

			$stmt = $this->pdo->prepare( "SELECT * FROM users WHERE company_id = ?" );
			$stmt->execute( [ $main_company_id ] );
			$admin = $stmt->fetch( PDO::FETCH_ASSOC );

			$actual_hash            = ConnectWise::generateCompanyAccessHash( $client['id'], $main_company_id, $admin['id'] );
			$hash                   = $session['hash'] ?? $actual_hash;
			$client['main_company'] = $main_company_id;
			$client['request_url']  = $hash;
			$client['view_portal']  = $hash;
			$client['actual_hash']  = $actual_hash;

			return $client;
		}, $companies );
		$responseData = array(
			'status'  => 'success',
			'message' => 'Companies list',
			'data'    => $companies,
			'paging'  => $paging
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function resetClientHash()
	{
		$hash       = $_POST['hash'] ?? false;
		$company_id = $_POST['company_id'] ?? false;
		$stmt       = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE company_id = ?" );
		$stmt->execute( [ $company_id ] );
		$session  = $stmt->fetch( PDO::FETCH_ASSOC );
		$new_hash = generateRandomString();

		if ( $session ) {
			$query = $this->pdo->prepare( "UPDATE `client_sessions` set hash = ? WHERE company_id = ?" );
			$query->execute( [ $new_hash, $company_id ] );

			$responseData = array(
				'status'  => 'success',
				'message' => 'Reset url successfully',
				'data'    => [ 'hash' => $new_hash ]
			);
			http_response_code( 200 );
		} else {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'Hash not found'
			);

			http_response_code( 500 );
		}

		echo json_encode( $responseData );
	}

	public function getcompanybyid()
	{
		$company_id = $_POST['company_id'];
		$companies  = [];
//		$companies      = [
//			[
//				'id'                => '1',
//				'po'                => 'p001',
//				'company_name'      => 'abc',
//				'view_portal '      => 'view',
//				'request_url'       => 'url',
//				'email'             => 'abc@gmail.com',
//				'receiver_contacts' => '090078601',
//			],
//			[
//				'id'                => '2',
//				'po'                => 'p002',
//				'company_name'      => 'abc2',
//				'view_portal '      => 'view',
//				'request_url'       => 'url',
//				'email'             => 'abc@gmail.com',
//				'receiver_contacts' => '090078601',
//			],
//			[
//				'id'                => '3',
//				'po'                => 'p003',
//				'company_name'      => 'abc3',
//				'view_portal '      => 'view',
//				'request_url'       => 'url',
//				'email'             => 'abc@gmail.com',
//				'receiver_contacts' => '090078601',
//			],
//			[
//				'id'                => '4',
//				'po'                => 'p004',
//				'company_name'      => 'abc4',
//				'view_portal '      => 'view',
//				'request_url'       => 'url',
//				'email'             => 'abc@gmail.com',
//				'receiver_contacts' => '090078601',
//			],
//
//
//		];
//		$target_company = $_POST['company_id'];
//		$arraymatch     = array_values( array_filter( $companies, function ( $item ) use ( $target_company ) {
//			return $item['id'] === $target_company;
//		} ) );
		$responseData = array(
			'status'  => 'success',
			'message' => 'Companies list',
			'data'    => $companies
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function get_all_po()
	{
		$page       = $_GET['page'] ?? 1;
		$limit      = $_GET['limit'] ?? 3;
		$search_po  = $_GET['search_po'] ?? false;
		$company    = $_GET['company_id'] ?? false;
		$conditions = [];

		if ( $company === false ) {
			$companies = $this->connectwise->getCompanies( 1, 1000 );
			$companies = array_column( $companies, 'id' );
		} else {
			$companies = [ $company ];
		}

		if ( $search_po !== false ) {
			$conditions[] = 'poNumber = "po-' . $search_po . '"';
		}

		$po     = $this->connectwise->getPurchaseOrders( $companies, $page, $limit, $conditions );
		$paging = false;

		if ( ! empty( $po ) ) {
			$paging = $this->connectwise->getPagination( $page );
			$po_ids = array_column( $po, 'id' );
			$po_ids = '(' . implode( ',', $po_ids ) . ')';
			$stmt   = $this->pdo->prepare( "SELECT * FROM purchase_orders WHERE po_id in {$po_ids}" );
			$stmt->execute();
			$po_statuses = $stmt->fetchAll( PDO::FETCH_ASSOC );

			$po = array_map( function ( $p ) use ( &$po_statuses ) {
				$p['systemStatus'] = null;

				if ( $po_statuses ) {
					foreach ( $po_statuses as $po_status ) {
						if ( $po_status['po_id'] == $p['id'] ) {
							$p['systemStatus'] = $po_status['status'];
						}
					}
				}

				$tracking_numbers = explode( PHP_EOL, $p['tracking_number'] );
				$tracking_infos   = [];

				foreach ( $tracking_numbers as $tracking_number ) {
					$stmt = $this->pdo->prepare( "SELECT * FROM trackings WHERE tracking_number = ?" );
					$stmt->execute( [ $tracking_number ] );
					$tracking_info = $stmt->fetch( PDO::FETCH_ASSOC );

					if ( $tracking_info && ! empty( $tracking_info['checkpoints'] ) ) {
						$tracking_info['checkpoints'] = json_decode( $tracking_info['checkpoints'], true );
					}

					$tracking_infos[] = $tracking_info;
				}

				$p['tracking_info'] = $tracking_infos;

				return $p;
			}, $po );
		}

		$responseData = array(
			"status"  => "success",
			"message" => "All Po's",
			"data"    => $po,
			"paging"  => $paging
		);

		http_response_code( 200 );
		echo json_encode( $responseData );
	}
}
