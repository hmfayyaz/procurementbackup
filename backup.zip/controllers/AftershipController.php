<?php

class AftershipController
{
	private $pdo;
	private $dbHelper;
	private $trackingHelper;

	public function __construct( $pdo, $dbHelper, $authorize, $connectwise, $trackingHelper )
	{
		$this->pdo            = $pdo;
		$this->dbHelper       = $dbHelper;
		$this->trackingHelper = $trackingHelper;
	}

	public function webhook()
	{
		$secret    = "fb1b9b9e1d261ccd864d457b19067d67";
		$input     = file_get_contents( "php://input" );
		$signature = base64_encode( hash_hmac( 'sha256', $input, $secret, true ) );
		$header    = $_SERVER['HTTP_AFTERSHIP_HMAC_SHA256'] ?? false;

		if ( $header == $signature ) {
			file_put_contents( dirname( __FILE__ ) . '/aftership.txt', PHP_EOL . PHP_EOL . $input, FILE_APPEND );
			$payload = json_decode( $input, true );
			if ( $payload['event'] == 'tracking_update' ) {
				$tracking        = $payload['msg'];
				$tracking_number = $tracking['tracking_number'];

				$this->trackingHelper->update_local_tracking( $tracking );

				if ( $tracking ) {
					sendEmail( "robert@hztech.biz", $tracking['subtag_message'], "Testing" );
					switch ( $tracking['subtag_message'] ) {
						case "Delivered":
							//sendEmail( "robert@hztech.biz", "Delivered", "Testing" );
							break;
					}
				}
			}
		}
	}
}
