<?php

class UserController
{
	private $pdo;
	private $dbHelper;
	private $authorize;
	private $connectwise;

	public function __construct( $pdo, $dbHelper, $authorize, $connectwise )
	{
		$this->pdo         = $pdo;
		$this->dbHelper    = $dbHelper;
		$this->authorize   = $authorize;
		$this->connectwise = $connectwise;
	}

	public function getorderbycompany()
	{
		$company_id   = $_POST['company_id'];
		$orders       = $this->connectwise->getPurchaseOrders( $company_id );
		$responseData = array(
			'status'  => 'success',
			'message' => 'Orders list',
			'data'    => $orders
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function getorderbypo()
	{
		$purchase = [
			[
				'title'  => 'Madison Geldart',
				'po'     => 'p001',
				'site'   => 'Alameda -1441 Webster street',
				'vendor' => 'Synnex',
				'orders' => [
					[
						'received'          => 'Open',
						'product_id'        => '1xF0N03161',
						'description'       => 'Lenovo Mounting Adapter for Desktop Computer',
						'purchase_quantity' => '1',
						'received_quantity' => '0',
						'action'            => 'Receive',
					],
					[
						'received'          => 'Pending',
						'product_id'        => '1xF0N03161',
						'description'       => 'Lenovo Mounting Adapter for Desktop Computer',
						'purchase_quantity' => '1',
						'received_quantity' => '0',
						'action'            => 'Receive',
					],

				],

			],
			[
				'title'  => 'Madison Geldart',
				'po'     => 'p002',
				'site'   => 'Alameda -1442 Webster street',
				'vendor' => 'Synnex',
				'orders' => [
					[
						'received'          => 'Open',
						'product_id'        => '2xF0N03161',
						'description'       => 'Lenovo Mounting Adapter for Desktop Computer',
						'purchase_quantity' => '2',
						'received_quantity' => '0',
						'action'            => 'Receive',
					],
				],

			],
			[
				'title'  => 'Madison Geldart',
				'po'     => 'p003',
				'site'   => 'Alameda -1443 Webster street',
				'vendor' => 'Synnex',
				'orders' => [
					[
						'received'          => 'Open',
						'product_id'        => '3xF0N03161',
						'description'       => 'Lenovo Mounting Adapter for Desktop Computer',
						'purchase_quantity' => '3',
						'received_quantity' => '0',
						'action'            => 'Receive',
					]
				],

			],
			[
				'title'  => 'Madison Geldart',
				'po'     => 'p004',
				'site'   => 'Alameda -1444 Webster street',
				'vendor' => 'Synnex',
				'orders' => [
					[
						'received'          => 'Open',
						'product_id'        => '4xF0N03161',
						'description'       => 'Lenovo Mounting Adapter for Desktop Computer',
						'purchase_quantity' => '4',
						'received_quantity' => '0',
						'action'            => 'Receive',
					]
				],

			],

		];
		$targetPo = $_POST['po'];

		$matchingArrays = array_values( array_filter( $purchase, function ( $item ) use ( $targetPo ) {
			return $item['po'] === $targetPo;
		} ) );

		$responseData = array(
			'status'  => 'success',
			'message' => 'Purchase Oders',
			'data'    => $matchingArrays
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}

	public function getpo()
	{
		$po             = [
			[
				'user_id' => '31',
				'po'      => [
					'p001',
					'p002',
				]
			],
			[
				'user_id' => '1',
				'po'      => [
					'p003',
					'p002',
				]
			],
			[
				'user_id' => '2',
				'po'      => [
					'p001',
					'p003',
				]
			],
			[
				'user_id' => '3',
				'po'      => [
					'p004',
					'p002',
				]
			],

		];
		$targetuser     = $this->authorize['id'];
		$matchingArrays = array_values( array_filter( $po, function ( $item ) use ( $targetuser ) {
			return $item['user_id'] == $targetuser;
		} ) );
		$responseData   = array(
			"status"  => "success",
			"message" => "User Po's",
			"data"    => $matchingArrays
		);
		http_response_code( 200 );
		echo json_encode( $responseData );
	}
}
