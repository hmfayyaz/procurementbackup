<?php
// include 'config/database.php';

class LoginController
{

	private $pdo;

	public function __construct( $pdo )
	{
		$this->pdo = $pdo;
	}

    function testdata()
    {

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle the request
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            // Return the preflight response for CORS requests
            http_response_code(200);
            exit();
        }
//        var_dump($_POST); die;
//        $data = date('d-m-Y H:i:s')." This is the data to be inserted into the file.\n";
        $data = $_POST ;
        $json_data = file_get_contents('php://input');
        // Decode the JSON data
        $decoded_data = json_decode($json_data, true);
        $filePath = 'data.txt';
//        var_dump($filePath); die;
        file_put_contents($filePath, $data, FILE_APPEND | LOCK_EX);

        echo "Data inserted successfully!";


    }

	public function loginUser()
	{
		$usernameOrEmail = $_POST['username'] ?? false;
		$password        = $_POST['password'] ?? false;
		$portal_url      = $_POST['portal'] ?? false;
		$is_super_admin  = $portal = false;

		if ( ! $usernameOrEmail || ! $password ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'Username/password required'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
		} else {

			$stmt = $this->pdo->prepare( "SELECT * FROM users WHERE username = ? OR email = ?" );
			$stmt->execute( [ $usernameOrEmail, $usernameOrEmail ] );
			$user           = $stmt->fetch( PDO::FETCH_ASSOC );

            if(!$user){
                // Invalid credentials
                $responseData = array(
                    'status'  => 'failed',
                    'message' => 'Invalid username/password'
                );
                http_response_code( 500 );
                echo json_encode( $responseData ); die();
            }
			$is_super_admin = $user['is_admin'] == 1;
            if($portal_url && $is_super_admin){
                $responseData = array(
                    'status'  => 'failed',
                    'message' => 'Access denied'
                );
                http_response_code( 500 );
                echo json_encode( $responseData );
                die;
            }
			if ( $is_super_admin ) {
				$portal = true;
			} else if ( ! $portal_url ) {
				$responseData = array(
					'status'  => 'failed',
					'message' => 'Portal url is required'
				);
				http_response_code( 500 );
				echo json_encode( $responseData );
				die;
			}

			try {
				if ( ! $is_super_admin ) {
					$stmt = $this->pdo->prepare( "SELECT p.*, m.url FROM portal_setting as p left join media_files m on p.logo_media = m.id WHERE p.portal_url = ?" );
					$stmt->execute( [ $portal_url ] );
					$portal = $stmt->fetch( PDO::FETCH_ASSOC );
				}

				if ( ! empty( $portal ) ) {
					if ( ! $is_super_admin ) {
						$stmt = $this->pdo->prepare( "SELECT * FROM users WHERE portal_url = ? AND (username = ? OR email = ?)" );
						$stmt->execute( [ $portal_url, $usernameOrEmail, $usernameOrEmail ] );
						$user = $stmt->fetch( PDO::FETCH_ASSOC );
					}

					$data = null;

					if ( $user && $user['password'] === md5( $password ) ) {

						$token = JWT::generateToken( rand() );
						if ( isset( $token ) ) {

							$query = $this->pdo->prepare( "UPDATE `users` set token = '$token' WHERE id = ?" );
							$query->execute( [ $user['id'] ] );

							$selectQuery = $this->pdo->prepare( "SELECT * FROM `users` WHERE id = ?" );
							$selectQuery->execute( [ $user['id'] ] );
							$updatedUser          = $selectQuery->fetch( PDO::FETCH_ASSOC );
							$data                 = $updatedUser;
							$data['color_scheme'] = $portal['color_scheme'] ?? false;
							$data['label']        = $portal['label'] ?? false;
							$data['portal_logo']  = $portal['url'] ?? false;
						}

						$responseData = array(
							'status'  => 'success',
							'message' => 'Login Successful',
							'data'    => $data
						);
						http_response_code( 200 );
						echo json_encode( $responseData );
					} else {
						// Invalid credentials
						$responseData = array(
							'status'  => 'failed',
							'message' => 'Invalid username/password'
						);
						http_response_code( 500 );
						echo json_encode( $responseData );
					}
				} else {
					$responseData = array(
						'status'  => 'failed',
						'message' => 'Invalid portal'
					);
					http_response_code( 500 );
					echo json_encode( $responseData );
				}
			} catch ( PDOException $e ) {
				// Handle the exception
				return null;
			}
		}
	}

	public function verifyClientAccess()
	{
		$posted_hash  = $_POST['hash'];
		$password     = isset( $_POST['pass'] ) ? $_POST['pass'] : false;
		$token        = JWT::generateToken( rand() );
		$responseData = array(
			'status'  => 'failed',
			'message' => 'Invalid client link'
		);
		http_response_code( 500 );
		$stmt = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE hash = ?" );
		$stmt->execute( [ $posted_hash ] );
		$session = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( ! $session ) {
			$hash_data = ConnectWise::decodeCompanyHash( $posted_hash );

			if ( $hash_data ) {
				$stmt = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE company_id = ?" );
				$stmt->execute( [ $hash_data['identifier'] ] );
				$company_session = $stmt->fetch( PDO::FETCH_ASSOC );

				if ( ! $company_session ) {
					$client_data = [
						'hash'       => $posted_hash,
						'session_id' => $token,
						'admin_id'   => $hash_data['admin_id'],
						'company_id' => $hash_data['identifier']
					];

					$helper = new DatabaseHelper( $this->pdo, 'client_sessions' );
					$helper->createRecord( $client_data );

					$stmt = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE hash = ?" );
					$stmt->execute( [ $posted_hash ] );
					$session = $stmt->fetch( PDO::FETCH_ASSOC );
				}
			}
		}

		if ( $session ) {
			$details = $this->getProtalDetails( $session );

			if ( $password !== false ) {
				$stmt = $this->pdo->prepare( "SELECT * FROM users WHERE id = ?" );
				$stmt->execute( [ $session['admin_id'] ] );
				$user = $stmt->fetch( PDO::FETCH_ASSOC );

				$stmt = $this->pdo->prepare( "SELECT * FROM portal_setting WHERE user_id = ?" );
				$stmt->execute( [ $user['id'] ] );
				$settings = $stmt->fetch( PDO::FETCH_ASSOC );

				if ( $settings['master_password'] == $password ) {
					$query = $this->pdo->prepare( "UPDATE `client_sessions` set session_id = ? WHERE hash = ?" );
					$query->execute( [ $token, $posted_hash ] );
					$responseData = array(
						'status' => 'success',
						'data'   => [
							'token'        => $token,
							'color_scheme' => $details["color_scheme"] ?? '',
							'portal_logo'  => $details["url"] ?? '',
							'label'        => $details["label"] ?? '',
						],

					);
					http_response_code( 200 );
				} else {
					$responseData = array(
						'status'  => 'failed',
						'message' => 'Incorrect Password',
					);

					http_response_code( 500 );
				}
			} else {
				$responseData = array(
					'status'       => 'success',
					'color_scheme' => $details["color_scheme"] ?? '',
					'label'        => $details["label"] ?? '',
					'portal_logo'  => $details["url"] ?? '',
				);
				http_response_code( 200 );
			}
		}
		echo json_encode( $responseData );
	}

	public function getPortal()
	{
		$name         = $_GET['name'] ?? false;
		$responseData = [ 'status' => 'error' ];

		if ( $name ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM portal_setting WHERE portal_url = ?" );
			$stmt->execute( [ $name ] );
			$portal = $stmt->fetch( PDO::FETCH_ASSOC );

			if ( $portal ) {
				$portal['logo_media_url'] = false;
				if ( ! empty( $portal['logo_media'] ) ) {
					$stmt = $this->pdo->prepare( "SELECT * FROM `media_files` where id = ?" );
					$stmt->execute( [ $portal['logo_media'] ] );
					$media                    = $stmt->fetch( PDO::FETCH_ASSOC );
					$portal['logo_media_url'] = $media['url'] ?? false;
				}

				$responseData['status'] = 'success';
				$responseData['data']   = [
					'logo'         => $portal['logo_media'],
					'logo_url'     => $portal['logo_media_url'],
					'label'        => $portal['label'],
					'color_scheme' => $portal['color_scheme'],
					'portal_url'   => $portal['portal_url'],
				];
			}
		}
		http_response_code( $responseData['status'] == 'success' ? 200 : 500 );
		echo json_encode( $responseData );
	}

	function getProtalDetails( $session )
	{
		$stmt = $this->pdo->prepare( "SELECT p.*, m.url FROM portal_setting as p left join media_files m on p.logo_media = m.id WHERE p.user_id = ?" );
		$stmt->execute( [ $session['admin_id'] ] );

		return $user = $stmt->fetch( PDO::FETCH_ASSOC );
	}
}
