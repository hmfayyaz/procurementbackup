<?php
class User {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function loginUser($username, $password) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                // User authenticated successfully
                return ['user_id' => $user['id'], 'username' => $user['username']];
            } else {
                // Invalid credentials
                return null;
            }
        } catch (PDOException $e) {
            // Handle the exception
            return null;
        }
    }
}
