<?php
require_once 'controllers/LoginController.php';
require_once 'controllers/SuperAdminController.php';
require_once 'controllers/PlansController.php';
require_once 'controllers/TransactionsController.php';
require_once 'controllers/PaymentController.php';
require_once 'controllers/PortalSettingController.php';
require_once 'controllers/AdminController.php';
require_once 'controllers/CompaniesController.php';
require_once 'controllers/UserController.php';
require_once 'controllers/ClientController.php';
require_once 'controllers/AftershipController.php';
require_once 'controllers/CronController.php';

$apiRoutes = [

	'api/login'        => 'LoginController@loginUser',
	'api/test'         => 'LoginController@testdata',
	'api/client_hash'  => 'LoginController@verifyClientAccess',
	'api/hash_reset1'  => 'LoginController@resetClientHash',
	'api/get_portal'   => 'LoginController@getPortal',
	'api/hash_reset'   => 'CompaniesController@resetClientHash',
	'api/admin_create' => 'SuperAdminController@store',
	'api/admin_update' => 'SuperAdminController@update',
	'api/admin_delete' => 'SuperAdminController@delete',

	'api/user_create' => 'AdminController@store',
	'api/user_update' => 'AdminController@update',
	'api/user_delete' => 'AdminController@delete',
	'api/user_get'    => 'AdminController@getUsers',

	'api/plan_get'               => 'PlansController@fetch',
	'api/plan_create'            => 'PlansController@store',
	'api/plan_update'            => 'PlansController@update',
	'api/transaction_get'        => 'TransactionsController@fetch',
	'api/payment_setting'        => 'PaymentController@fetch',
	'api/payment_setting_update' => 'PaymentController@update',
	'api/portal_setting'         => 'PortalSettingController@fetch',
	'api/portal_setting_update'  => 'PortalSettingController@update',
	'api/upload_media'           => 'PortalSettingController@upload_media',
	'api/get_media'              => 'PortalSettingController@get_media',
	'api/get_companies'          => 'CompaniesController@getcompanies',
	'api/get_companies_by_id'    => 'CompaniesController@getcompanybyid',
	'api/get_order_by_company'   => 'UserController@getorderbycompany',
	'api/get_all_po'             => 'CompaniesController@get_all_po',

	'api/get_order_by_po'        => 'ClientController@getorderbypo',
	'api/get_po'                 => 'ClientController@getpo',
	'api/add_tracking_number'    => 'ClientController@add_tracking_number',
	'api/receive_order_quantity' => 'ClientController@receive_quantity',
	'api/receive_e_signature'    => 'ClientController@receive_signature',
	'api/get_tracking_info'      => 'ClientController@tracking_info',

	'webhook/aftership' => 'AftershipController@webhook',

	'cron/tracking_numbers' => 'CronController@tracking_numbers',
	'cron/track'            => 'CronController@track',
];
