<?php

ini_set( 'display_errors', 1 );
ini_set( 'display_startup_errors', 1 );
error_reporting( E_ALL );

require __DIR__ . '/vendor/autoload.php';

header( "Content-Type: application/json; charset=UTF-8" );
header( 'Access-Control-Allow-Origin: *' );
header( 'Access-Control-Allow-Methods: GET, POST' );
header( "Access-Control-Allow-Headers: X-Requested-With" );
header( "access-control-allow-credentials: true" );
header( "access-control-allow-origin: *" );

if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
	header( 'Access-Control-Allow-Origin: *' );
	header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
	header( 'Access-Control-Allow-Headers: Content-Type, Authorization' );
	header( 'Access-Control-Max-Age: 86400' ); // 24 hours cache
	http_response_code( 200 );
	exit;
}

// Include necessary files
include_once 'config/config.php';
include_once 'utils/tools.php';
include_once 'utils/jwt.php';
include_once 'objects/user.php';
include_once 'includes/ConnectWise.php';
include_once 'includes/DatabaseHelper.php';
include_once 'includes/TrackingHelper.php';
include_once 'router.php';
