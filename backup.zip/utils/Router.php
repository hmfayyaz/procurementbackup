<?php

class Router {
    private $routes = [];

    public function get($path, $handler) {
        $this->routes['GET'][$path] = $handler;
    }

    public function dispatch() {
        $requestUri = $_SERVER['REQUEST_URI'];
        $method = $_SERVER['REQUEST_METHOD'];

        foreach ($this->routes[$method] as $route => $handler) {
            $pattern = str_replace('/', '\/', $route);
            $pattern = '/^' . str_replace('{id}', '(\d+)', $pattern) . '$/';

            if (preg_match($pattern, $requestUri, $matches)) {
                $handlerParts = explode('@', $handler);
                $controllerName = $handlerParts[0];
                $methodName = $handlerParts[1];

                require_once "controllers/{$controllerName}.php";
                call_user_func([$controllerName, $methodName], $matches);

                return;
            }
        }

        // Handle 404 Not Found
        header('HTTP/1.1 404 Not Found');
        echo '404 Not Found';
    }
}
