<?php

class AUTHORIZED
{

	private $pdo;

	public function __construct( $pdo )
	{
		$this->pdo = $pdo;
	}

	public function verifyUser()
	{

		$headers = getallheaders();
		$token   = isset( $headers['Authorization'] ) ? str_replace( 'Bearer ', '', $headers['Authorization'] ) : null;

		$stmt = $this->pdo->prepare( "SELECT * FROM users WHERE token = ? and is_admin IN (0,1,2)" );
		$stmt->execute( [ $token ] );
		$user = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( ! empty( $user ) ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM portal_setting WHERE user_id = ?" );
			$stmt->execute( [ $user['id'] ] );
			$settings         = $stmt->fetch( PDO::FETCH_ASSOC );
			$user['settings'] = $settings;
		}

		return $user;
	}

	public function verifyClient()
	{
		$headers = getallheaders();
		$token   = isset( $headers['Authorization'] ) ? str_replace( 'Bearer ', '', $headers['Authorization'] ) : null;

		$stmt = $this->pdo->prepare( "SELECT * FROM client_sessions WHERE session_id = ?" );
		$stmt->execute( [ $token ] );
		$session = $stmt->fetch( PDO::FETCH_ASSOC );

		if ( ! empty( $session ) ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM portal_setting WHERE user_id = ?" );
			$stmt->execute( [ $session['admin_id'] ] );
			$settings            = $stmt->fetch( PDO::FETCH_ASSOC );
			$session['settings'] = $settings;
		}

		return $session;
	}
}
