<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function generateRandomString( $length = 10 )
{
	$characters   = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$randomString = '';

	for ( $i = 0; $i < $length; $i ++ ) {
		$randomString .= $characters[ rand( 0, strlen( $characters ) - 1 ) ];
	}

	return $randomString;
}

function getURLParameterValue( $param, $url )
{
	$pattern = '/[?&]' . preg_quote( $param, '/' ) . '=([^&>]+)/';
	if ( preg_match( $pattern, $url, $matches ) ) {
		$val = urldecode( $matches[1] );

		return $val;
	}

	return false;
}

function sendEmail( $to, $subject, $body, &$error, $options = [ 'name' => false ] )
{
	$mail = new PHPMailer( true );

	try {
		//Server settings
		$mail->SMTPDebug = SMTP::DEBUG_SERVER;
		$mail->isSMTP();
		$mail->Host       = 'smtp.sendgrid.net';
		$mail->SMTPAuth   = true;
		$mail->Username   = 'apikey';
		$mail->Password   = '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';
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		$mail->Port       = 587;

		//Recipients
		$mail->setFrom( MAIL_FROM, MAIL_FROM_NAME );
		$mail->addAddress( $to, $options['name'] );     //Add a recipient
		$mail->addReplyTo( MAIL_FROM, MAIL_FROM_NAME );

		//Content
		$mail->isHTML( true );                                  //Set email format to HTML
		$mail->Subject = $subject;
		$mail->Body    = $body;

		$mail->send();

		return true;
	} catch ( Exception $e ) {
		$error = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

		return false;
	}
}
