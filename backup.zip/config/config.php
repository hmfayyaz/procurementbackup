<?php
define( 'DB_HOST', 'localhost' );
define( 'DB_NAME', 'mjyygunxub' );
define( 'DB_USER', 'mjyygunxub' );
define( 'DB_PASSWORD', 'D8cbn5esFY' );
define( 'BASEURL', 'https://phpstack-653970-4214570.cloudwaysapps.com/' );
define( 'MAIL_FROM', 'git@hztech.biz' );
define( 'MAIL_FROM_NAME', 'DTSIT' );

// Establish database connection
try {
	$pdo = new PDO( "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD );
	$pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
} catch ( PDOException $e ) {
	echo "Database Connection Error: " . $e->getMessage();
	exit();
}
