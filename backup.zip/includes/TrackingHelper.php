<?php

class TrackingHelper
{
	private $pdo;
	private $vendorUrl = 'https://api.aftership.com/tracking/2024-01';
	private $vendorKey = 'asat_0585c20d3e5642ab8238049e58410fe3';

	public function __construct( $pdo )
	{
		$this->pdo = $pdo;
	}

	public function create_tracking( $tracking_numbers, $po_id )
	{
		foreach ( $tracking_numbers as $tracking_number ) {
			$stmt = $this->pdo->prepare( "SELECT * FROM trackings WHERE po_id = ? AND tracking_number = ?" );
			$stmt->execute( [ $po_id, $tracking_number ] );
			$tn_record = $stmt->fetch( PDO::FETCH_ASSOC );

			if ( empty( $tn_record ) ) {
				$local  = $this->get_local_tracking( $tracking_number );
				$helper = new DatabaseHelper( $this->pdo, 'trackings' );
				$data   = [
					'tracking_number' => $tracking_number,
					'po_id'           => $po_id,
				];

				if ( ! empty( $local ) ) {
					$data          = $local;
					$data['po_id'] = $po_id;

					unset( $data['id'] );
				}

				$helper->createRecord( $data );
			}
		}
	}

	public function get_local_tracking( $tracking_number )
	{
		$stmt = $this->pdo->prepare( "SELECT * FROM trackings WHERE tracking_number = ?" );
		$stmt->execute( [ $tracking_number ] );

		return $stmt->fetch( PDO::FETCH_ASSOC );
	}

	public function update_local_tracking( $tracking )
	{
		$id              = $tracking['id'] ?? false;
		$query           = "UPDATE trackings SET";
		$sets            = [];
		$tracking_number = $tracking['tracking_number'] ?? false;

		if ( $id ) {
			$res      = $this->get_tracking_by_id( $id );
			$tracking = $res['data']['tracking'] ?? false;
		}

		if ( ! empty( $tracking ) && ! empty( $tracking_number ) ) {
			$data = $this->mapping( $tracking );

			foreach ( $data as $k => $v ) {
				$sets[] = "{$k}='{$v}'";
			}

			$query .= " " . implode( ',', $sets );
			$query .= " WHERE tracking_number = ?";

			$stmt = $this->pdo->prepare( $query );
			$stmt->execute( [ $tracking_number ] );
		}
	}

	public function analyze_tracking_numbers( $tracking_numbers )
	{
		foreach ( $tracking_numbers as $po_id => $tracking_number ) {
			$this->create_tracking( $tracking_number, $po_id );
		}
	}

	public function create_vendor_tracking( $tracking_number )
	{
		return $this->request( "trackings", [ 'tracking' => [ 'tracking_number' => $tracking_number ] ], 'POST' );
	}

	public function get_tracking_by_id( $id )
	{
		return $this->request( "trackings/${id}" );
	}

	public function mapping( $tracking )
	{
		$keys = [
			'courier_tracking_link',
			'id',
			'subtag_message',
			'checkpoints',
			'destination_raw_location',
			'origin_raw_location',
			'transit_time'
		];
		$data = [ 'status' => 'fetched' ];

		foreach ( $keys as $key ) {
			if ( isset( $tracking[ $key ] ) ) {
				switch ( $key ) {
					case "checkpoints":
						$data[ $key ] = json_encode( $tracking[ $key ] );
						break;
					case "id":
						$data['source_id'] = $tracking[ $key ];
						break;
					default:
						$data[ $key ] = $tracking[ $key ];
				}
			}
		}

		return $data;
	}

	private function request( $path, $payload = false, $method = 'GET' )
	{
		$curl    = curl_init();
		$options = array(
			CURLOPT_URL            => "{$this->vendorUrl}/{$path}",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING       => '',
			CURLOPT_MAXREDIRS      => 10,
			CURLOPT_TIMEOUT        => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_HTTPHEADER     => array(
				"as-api-key: {$this->vendorKey}",
				'Content-Type: application/json'
			),
		);

		if ( $payload ) {
			$options[ CURLOPT_POSTFIELDS ] = json_encode( $payload );
		}

		if ( $method !== 'GET' ) {
			$options[ CURLOPT_CUSTOMREQUEST ] = $method;
		}

		curl_setopt_array( $curl, $options );

		$response = curl_exec( $curl );

		curl_close( $curl );

		return json_decode( $response, true );
	}
}
