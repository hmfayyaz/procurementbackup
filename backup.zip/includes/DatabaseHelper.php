<?php

class DatabaseHelper
{
	private $pdo;
	private $tableName;

	public function __construct( $pdo, $tableName )
	{
		$this->pdo       = $pdo;
		$this->tableName = $tableName;
	}

	public function createRecord( $data )
	{

		try {
			$columns = implode( ", ", array_keys( $data ) );
			$values  = implode( ", ", array_fill( 0, count( $data ), '?' ) );

			$stmt = $this->pdo->prepare( "INSERT INTO {$this->tableName} ($columns) VALUES ($values)" );
			$stmt->execute( array_values( $data ) );

			// Return the newly created record ID
			return $this->pdo->lastInsertId();
		} catch ( PDOException $e ) {

			// Handle the exception
			return null;
		}
	}

	public function updateRecord( $id, $data )
	{
		try {
			$setClause = implode( " = ?, ", array_keys( $data ) ) . " = ?";
			$stmt      = $this->pdo->prepare( "UPDATE {$this->tableName} SET $setClause WHERE id = ?" );
			$stmt->execute( array_merge( array_values( $data ), [ $id ] ) );

			// Return true if the update was successful
			return $stmt->rowCount() > 0;
		} catch ( PDOException $e ) {
			// Handle the exception
			return false;
		}
	}

	public function deleteRecord( $id )
	{
		try {
			$stmt = $this->pdo->prepare( "DELETE FROM {$this->tableName} WHERE id = ?" );
			$stmt->execute( [ $id ] );

			// Return true if the deletion was successful
			return $stmt->rowCount() > 0;
		} catch ( PDOException $e ) {
			// Handle the exception
			return false;
		}
	}
}
