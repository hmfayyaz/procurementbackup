<?php

//const CW_ENDPOINT    = 'https://connect.dhsforyou.com/v4_6_release/apis/3.0/';
//const CW_CLIENT_ID   = '2d878268-ea74-4cab-8b2c-4e49ffe08228';
//const CW_PUBLIC_KEY  = 'AgkOHwNJvHYSxiox';
//const CW_PRIVATE_KEY = 'oveoV0isTjaUfs2l';
//const CW_COMPANY_ID  = 'dhs';

class ConnectWise
{
	private static $instance;
	private $company_id;
	private $endpoint;
	private $client_id;
	private $public;
	private $private;
	private $response_headers;

	public static function getInstance( $endpoint, $client_id, $public, $private, $company_id )
	{
		if ( ! isset( self::$instance ) ) {
			self::$instance = new ConnectWise( $endpoint, $client_id, $public, $private, $company_id );
		}

		return self::$instance;
	}

	public function __construct( $endpoint, $client_id, $public, $private, $company_id )
	{
		$this->endpoint   = $endpoint;
		$this->client_id  = $client_id;
		$this->public     = $public;
		$this->private    = $private;
		$this->company_id = $company_id;
	}

	public function getCompany()
	{
		$companies = $this->get( 'company/companies', [
			'conditions=' . urlencode( 'identifier = "' . $this->company_id . '"' )
		] );

		return ! empty( $companies[0] ) ? $companies[0] : false;
	}

	public function getCompanyId()
	{
		return $this->company_id;
	}

	public function getResponseHeaders()
	{
		return $this->response_headers;
	}

	public function generateAuth()
	{
		//$company_id = $this->company_id ? $this->company_id : CW_COMPANY_ID;

		return base64_encode( $this->company_id . "+" . $this->public . ":" . $this->private );
	}

	private function curl( $method, $url, $data = false )
	{
		$curl = curl_init();
		$request_headers = array(
			'Content-Type: application/json',
			'Authorization: Basic ' . $this->generateAuth(),
			'clientId: ' . $this->client_id
		);
		$request_body = ! empty( $data ) ? json_encode( $data ) : false;

		curl_setopt_array( $curl, array(
			CURLOPT_URL            => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING       => '',
			CURLOPT_MAXREDIRS      => 10,
			CURLOPT_TIMEOUT        => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => $method,
			CURLOPT_HEADER         => true,
			CURLOPT_HTTPHEADER     => $request_headers,
			CURLOPT_POSTFIELDS     => $request_body,
		) );

		$curl_response = curl_exec( $curl );
		$response      = explode( "\r\n\r\n", $curl_response, 2 );
		$headers       = $response[0] ?? "";
		$body          = $response[1] ?? "";

		if ( empty( $headers ) || empty( $body ) ) {
			return [];
		}

		$headerLines            = explode( "\r\n", $headers );
		$this->response_headers = [];

		foreach ( $headerLines as $headerLine ) {
			$kv                               = explode( ': ', $headerLine );
			$this->response_headers[ $kv[0] ] = $kv[1] ?? null;
		}

		curl_close( $curl );

		return json_decode( $body, true );
	}

	public function getPagination( $page )
	{
		$links = $this->response_headers['Link'] ?? "";
		$links = explode( ',', $links );
		$pages = [ 'current' => intval( $page ) ];

		foreach ( $links as $l ) {
			$l    = explode( '; ', $l );
			$link = $l[0] ?? false;
			$rel  = $l[1] ?? false;

			if ( $link && $rel ) {
				$param_value = getURLParameterValue( "page", $link );

				if ( $param_value ) {
					if ( strrpos( $rel, 'prev' ) ) {
						$pages['prev'] = intval( $param_value );
					}

					if ( strrpos( $rel, 'next' ) ) {
						$pages['next'] = intval( $param_value );
					}

					if ( strrpos( $rel, 'last' ) ) {
						$pages['last'] = intval( $param_value );
					}
				}
			}
		}

		return $pages;
	}

	public function get( $uri, $args = [] )
	{
		$url = $this->endpoint . $uri . '?' . implode( '&', $args );

		return $this->curl( 'GET', $url );
	}

	public function post( $uri, $data = [] )
	{
		$url = $this->endpoint . $uri;

		return $this->curl( 'POST', $url, $data );
	}

	public function put( $uri, $data = [] )
	{
		$url = $this->endpoint . $uri;

		return $this->curl( 'PUT', $url, $data );
	}

	public function delete( $uri, $data = [] )
	{
		$url = $this->endpoint . $uri;

		return $this->curl( 'DELETE', $url );
	}

	public function getCompanies( $page = 1, $limit = 100 )
	{
		$companies = $this->get( 'company/companies', [
			'childConditions=' . urlencode( 'types/name = "Client"' ),
			'conditions=' . urlencode( 'status/name = "Active"' ),
			'orderBy=' . urlencode( 'name' ),
			'pageSize=' . $limit,
			'page=' . $page
		] );

		if ( empty( $companies['code'] ) ) {
			$companies = array_map( function ( $client ) {
				return [
					'id'                => $client['identifier'],
					'company_name'      => $client['name'],
					'email'             => $client['website'],
					'receiver_contacts' => '', //implode( PHP_EOL, $this->getCompanyContacts( $client['identifier'] ) )
				];
			}, $companies );
		} else {
			$companies = [];
		}

		return $companies;
	}

	public function getPurchaseOrders( $company_id = false, $page = 1, $limit = 100, $conditions = [] )
	{
		//$conditions = 'customerCompany/identifier = "' . $company_id . '" and status/name != "Closed"';
		$company_id = $company_id ?: $this->getCompanyId();
		$limit      = $limit ?? 3;
		if ( $company_id ) {
			//$conditions[] = 'customerCompany/identifier = "' . $company_id . '"';

			if ( ! is_array( $company_id ) ) {
				$company_id = [ $company_id ];
			}

			$company_id   = '("' . implode( '","', $company_id ) . '")';
			$conditions[] = 'customerCompany/identifier in ' . $company_id;
		}

		$conditions[]    = 'status/name != "Closed"';
		$conditions      = implode( ' and ', $conditions );
		$purchase_orders = $this->get( 'procurement/purchaseorders', [
			'conditions=' . urlencode( $conditions ),
			'orderBy=poNumber',
			'pageSize=' . $limit,
			'page=' . $page
		] );

		if ( ! empty( $purchase_orders['code'] ) ) {
			$purchase_orders = [];
		}

		$purchase_orders = array_map( function ( $p ) {
			return [
				'id'               => $p['id'],
				'status'           => $p['status']['name'],
				'tracking_number'  => $p['trackingNumber'] ?: "N/A",
				'company_id'       => $p['customerCompany']['identifier'],
				'company'          => $p['customerCompany']['name'],
				'poNumber'         => $p['poNumber'],
				'customerSiteName' => ! empty( $p['customerSiteName'] ) ? $p['customerSiteName'] : false,
				'vendorName'       => ! empty( $p['vendorCompany']['name'] ) ? $p['vendorCompany']['name'] : false
			];
		}, $purchase_orders );

		return $purchase_orders;
	}

	public function getPurchaseOrder( $purchase_order_id )
	{
		return $this->get( "procurement/purchaseorders/{$purchase_order_id}", [] );
	}

	public function getLineItems( $purchase_order_id, $page = 1, $limit = 20, $combine = true )
	{
		$line_items = $this->get( "procurement/purchaseorders/{$purchase_order_id}/lineitems", [
			'orderBy=' . urlencode( 'product/identifier' ),
			'pageSize=' . $limit,
			'page=' . $page
		] );
		$items      = [];

		if ( $combine ) {
			foreach ( $line_items as $line_item ) {
				if ( isset( $items[ $line_item['product']['identifier'] ] ) ) {
					$items[ $line_item['product']['identifier'] ]['quantity']         += $line_item['quantity'];
					$items[ $line_item['product']['identifier'] ]['receivedQuantity'] += $line_item['receivedQuantity'];
				} else {
					$items[ $line_item['product']['identifier'] ] = $line_item;
				}
			}

			foreach ( $items as $k => $item ) {
				$rq                          = $items[ $k ]['receivedQuantity'] = $item['receivedQuantity'] ?? 0;
				$status                      = $item['quantity'] == $rq ? 'Received in Full' : ( $rq > 0 ? 'Received Partial' : "Open" );
				$items[ $k ]['systemStatus'] = $status;
			}
		} else {
			$items = $line_items;
		}

		return array_values( $items );
	}

	public function getLineItem( $purchase_order_id, $line_item_id )
	{
		$line_item = $this->get( "procurement/purchaseorders/{$purchase_order_id}/lineitems/{$line_item_id}", [] );

		return $line_item;
	}

	public function getCompanyContacts( $company_id = false, $type = "Email", $page = 1, $limit = 20 )
	{
		$company_id = $company_id ?: $this->getCompanyId();
		$contacts   = $this->get( 'company/contacts', [
			'conditions=' . urlencode( 'company/identifier = "' . $company_id . '"' ),
			'childConditions=' . urlencode( 'types/name = "Product Receiver" and communicationItems/type/name = "Email"' ),
			'pageSize=' . $limit,
			'page=' . $page
		] );

		if ( $type ) {
			$emails = [];

			foreach ( $contacts as $contact ) {
				foreach ( $contact['communicationItems'] as $communication_item ) {
					if ( $communication_item['type']['name'] == 'Email' ) {
						$emails[] = $communication_item['value'];
					}
				}
			}

			return $emails;
		}

		return $contacts;
	}

	public function updateLineItems( $purchase_order_id, $line_items )
	{
		return $this->put( "procurement/purchaseorders/{$purchase_order_id}/lineitems/bulk", $line_items );
	}
	public function updatePurchaseOrder( $purchase_order_id, $purchase_order )
	{
		return $this->put( "procurement/purchaseorders/{$purchase_order_id}", $purchase_order );
	}

	public function addLineItem( $purchase_order_id, $line_item )
	{
		return $this->post( "procurement/purchaseorders/{$purchase_order_id}/lineitems", $line_item );
	}

	public static function sanitize( $text )
	{
		return str_replace( ' ', '_', $text );
	}

	public static function generateCompanyAccessHash( $identifier, $main_company_id, $admin_id )
	{
		return base64_encode( "{$identifier}:{$main_company_id}:{$admin_id}:DECODED" );
	}

	public static function decodeCompanyHash( $hash )
	{
		$try = 1000;
		$i   = 0;

		while ( strrpos( $hash, ":DECODED" ) === false ) {
			$hash = base64_decode( $hash );

			if ( $i ++ > $try ) {
				return false;
			}
		}

		$hash_data = explode( ':', $hash );
		$hash_data = [
			'identifier'      => $hash_data[0],
			'main_company_id' => $hash_data[1],
			'admin_id'        => $hash_data[2]
		];

		return $hash_data;
	}
}
