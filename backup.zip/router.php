<?php


// Include the API routes file
require_once 'routes.php';
include 'utils/authorized.php';

// Get the requested URI
$requestUri = $_SERVER['REQUEST_URI'];
$requestUri = strtok( $requestUri, '?' );
$requestUri = trim( $requestUri, '/' );

// Get the protocol (HTTP or HTTPS)
$protocol = isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';

// Get the domain name
$domainName = $_SERVER['HTTP_HOST'];

// Get the current project directory (without the script name)
$projectDir = dirname( $_SERVER['SCRIPT_NAME'] );

// Construct the project URL
$projectUrl = "$protocol://$domainName$projectDir";

// Remove the project directory from the request URI
$requestUri = str_replace( str_replace( '/', '', $projectDir ), '', $requestUri );
$requestUri = trim( $requestUri, '/' );
// Find a matching route
if ( array_key_exists( $requestUri, $apiRoutes ) ) {
	list( $controller, $action ) = explode( '@', $apiRoutes[ $requestUri ] );
	global $pdo;
	global $dbHelper;
	global $authorize;
	global $connectwise;
	global $trackingHelper;

	$trackingHelper   = new TrackingHelper( $pdo );
	$authorize_object = new AUTHORIZED( $pdo );
	$authorize        = $authorize_object->verifyUser();
	$client_authorize = $authorize_object->verifyClient();

	if ( $authorize ) {
		$settings = $authorize['settings'];
	} else if ( $client_authorize ) {
		$settings  = $client_authorize['settings'];
		$authorize = $client_authorize;
	}

	//$endpoint    = $settings['end_point'] ?? 'https://connect.dhsforyou.com/v4_6_release/apis/3.0/';
	//$client_id   = $settings['client_id'] ?? '2d878268-ea74-4cab-8b2c-4e49ffe08228';
	//$public      = $settings['public_key'] ?? 'AgkOHwNJvHYSxiox';
	//$private     = $settings['private_key'] ?? 'oveoV0isTjaUfs2l';
	//$company_id  = $settings['company_id'] ?? 'dhs';

	$endpoint   = $settings['cw_end_point'] ?? false;
	$client_id  = $settings['cw_client_id'] ?? false;
	$public     = $settings['cw_public_key'] ?? false;
	$private    = $settings['cw_private_key'] ?? false;
	$company_id = $settings['cw_company_id'] ?? false;

	$connectwise   = ConnectWise::getInstance( $endpoint, $client_id, $public, $private, $company_id );
	$public_routes = [
		'api/get_portal',
		'api/client_hash',
		'api/login',
		'api/admin_create',
		'api/plan_get',
		'api/user_get',
		'webhook/aftership',
		'cron/tracking_numbers',
		'cron/track',
	];

	if ( ! in_array( $requestUri, $public_routes ) ) {
		if ( empty( $authorize ) && empty( $client_authorize ) ) {
			$responseData = array(
				'status'  => 'failed',
				'message' => 'Access denied. Unauthorized Token'
			);
			http_response_code( 500 );
			echo json_encode( $responseData );
			die;
		}
	}
	// Create an instance of the controller
	$controllerInstance = new $controller( $pdo, $dbHelper, $authorize, $connectwise, $trackingHelper );

	// Call the specified action
	$controllerInstance->$action();
} else {
	// Handle 404 Not Found for API routes
//	header( 'HTTP/1.1 404 Not Found' );
	http_response_code( 500 );
	echo json_encode( [ 'message' => 'Route not found' ] );
}
